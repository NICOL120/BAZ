export const SYMBOLS = {
  ASTRO: 'ASTRO',
  VKR: 'VKR',
  TPT: 'TPT',
  BLUNA: 'bLUNA',
  RED: 'RED',
  SAYVE: 'SAYVE',
};
